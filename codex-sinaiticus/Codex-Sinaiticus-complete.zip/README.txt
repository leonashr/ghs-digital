Codex Sinaiticus - Complete Offline Edition

Extract Codex-Sinaiticus-complete.html. Open directly in a modern browser.
All 21,882 preserved verse units and their Greek tokens are embedded in the HTML.
Actual source totals are available in the HTML, so do not trust this description alone.
The edition does NOT provide a reviewed translation for every Greek word.
Images are only on the official website and require internet.
Data: Codex Sinaiticus Project / ITSEE University of Birmingham.
License: CC BY-NC-SA 3.0. Noncommercial use; attribution; share alike.
